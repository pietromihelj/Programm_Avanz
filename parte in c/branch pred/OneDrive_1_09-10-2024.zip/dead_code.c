#include <stdio.h>

int main(int argc, char * argv[])
{
  int sum = 0;
  for (int i = 0; i < 1000; i++) {
    sum++;
  }
  printf("finito\n");
  return 0;
}
